interface MancalaPlayer
{
public int getMove(MancalaGameState gs) throws Exception;
}
