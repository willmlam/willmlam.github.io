import java.io.Console;
public class interactive_Player implements MancalaPlayer
{
private int player;

public interactive_Player (int playerNum) {
  player = playerNum;
}

public int getMove(MancalaGameState gs) throws Exception {
    return Integer.parseInt(System.console().readLine());
}


}
